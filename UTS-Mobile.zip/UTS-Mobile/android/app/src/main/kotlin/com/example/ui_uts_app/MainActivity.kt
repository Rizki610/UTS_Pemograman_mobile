package com.example.ui_uts_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
